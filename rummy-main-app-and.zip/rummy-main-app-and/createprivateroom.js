import React,{useState}from "react";
import { View, Text, TouchableOpacity, TextInput, StyleSheet,Animated,Dimensions,TouchableWithoutFeedback,Image } from 'react-native';
import * as SecureStore from 'expo-secure-store';
import Slider from '@react-native-community/slider';
import { useNavigation } from '@react-navigation/native';

const CreatePrivateRoom = ()=>{
  const navigation = useNavigation();
  const [activeTab, setActiveTab] = useState(1); // Default active tab is 0
  const [poolTab, setPoolTab] = useState(101);
  const [playerTab, setPlayerTab] = useState(2);

  const handleSelectPlayers = (index) => {
    setPlayerTab(index);
  };

  const handleSelectPool = (index) => {
    setPoolTab(index);
  };

   const [sliderValue, setSliderValue] = useState(0);
    // Define custom step values
    const customSteps = [1, 5, 10, 20, 50, 100, 250, 500, 1000];
    const pointValues = [0.0125, 0.0625, 0.125, 0.25, 0.625, 1.25, 3.125, 6.25, 12.5];
    // Handle slider change
    const handleSliderChange = (value) => {
      setSliderValue(value);
    };
  
    // Map slider value to corresponding custom step
    const getCurrentStepValue = () => customSteps[sliderValue];
  
    const getCurrentPointValue = () => pointValues[sliderValue];

    const openGame = (roomId) => {
        navigation.navigate('Game', { roomId });
      }
      const shuffleCards = async(roomId)=>{
    
        try {
          const response = await fetch(`https://rummy-apigateway-v1.onrender.com/api/room/shuffle-start/${roomId}`,{
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            }
          });
    
          console.log('Response status:', queryParams);
          console.log('Response headers:', response.headers);
          if (response.ok) {
    
           } else {
            console.log('Invalid credentials. Please try again.');
            }
          }
         catch (error) {
          console.log('Error submitting form:', error);
        }
    }
    
      const InitializeCards = async(roomId)=>{
        const activeTabValue = (activeTab === 2 || activeTab === 6) ? 6 : 9;
          try {
            const response = await fetch(`https://rummy-apigateway-v1.onrender.com/api/cards/initialize-${activeTabValue}/${roomId}`,{
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              }
            });
      
            console.log('Response status:', queryParams);
            console.log('Response headers:', response.headers);
            if (response.ok) {
    
             } else {
              console.log('Invalid credentials. Please try again.');
              }
            }
           catch (error) {
            console.log('Error submitting form:', error);
          }
      }
    
  
        const createRoom = async()=>{
        const playerId = await SecureStore.getItemAsync('playerId');
          const roomDetails = {
            roomSize: playerTab,
            roomType: 'Deal',
            gameMode: 'Cash',
            gameStatus: 'Waiting',
            pointValue: getCurrentPointValue(), 
            playerId: playerId,
            issuedPoint: 0, 
            totalRounds: 1, 
            entryType: 'Money', 
            entryPrice: getCurrentStepValue(),
            visibility: 'Private',
          };
      
          const queryParams = new URLSearchParams(roomDetails).toString();
          try {
            const response = await fetch(`https://rummy-apigateway-v1.onrender.com/api/room/join-or-create-room?${queryParams}`,{
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              }
            });

            
      
            console.log('Response status:', queryParams);
            console.log('Response headers:', response.headers);
            if (response.ok) {
              const Data = await response.json();
              const roomId = Data.roomId
              const gameStatus =Data.gameStatus
              if(gameStatus==='Waiting'){
                InitializeCards(roomId)
                shuffleCards(roomId)
              }
              openGame(roomId);
             } else {
              console.log('Invalid credentials. Please try again.');
              }
            }
           catch (error) {
            console.log('Error submitting form:', error);
          }
        }

        const incrementValue = () => {
          if (sliderValue < customSteps.length - 1) {
            setSliderValue(sliderValue + 1);
          }
        };
      
        const decrementValue = () => {
          if (sliderValue > 0) {
            setSliderValue(sliderValue - 1);
          }
        };
    return(
        <View>
            <View style={{height:40}}>

            </View>
            <View style={{backgroundColor:'#526E48',height:'60',flexDirection:'row',alignItems:'center'}}>
                <Text style={{color:'#fff',fontSize:16,fontWeight:700,paddingHorizontal:20}}>Create Room</Text>
            </View>
                  {/* <View style={styles.tabContainer}>
                    <View style={{flexDirection:'row',backgroundColor:'#fff',borderRadius:8,backgroundColor:'#526E48'}}>
                    <TouchableOpacity
                      style={[styles.tab, activeTab === 0 && styles.activeTab]}
                      onPress={() => handleTabPress(0)}
                    >
                      <Text style={[styles.tabText, activeTab === 0 && styles.activeTabText]}>
                        Free
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[styles.tab, activeTab === 1 && styles.activeTab]}
                      onPress={() => handleTabPress(1)}
                    >
                      <Text style={[styles.tabText, activeTab === 1 && styles.activeTabText]}>
                        Cash
                      </Text>
                    </TouchableOpacity>
                    </View>
                    <View></View>
            
                  </View> */}
            <View style={{flexDirection:'column',gap:20,paddingVertical:20}}>

                      <View style={{flexDirection:'column',gap:10}}>
                  <Text style={{textAlign:'center'}}>Select Players</Text>
                        <View style={{flexDirection:'row',justifyContent:'center'}}>
                          {/* Tab 1 */}
                          <TouchableOpacity
                            style={[styles.tabs, playerTab === 2 && styles.activeTab]}
                            onPress={() => handleSelectPlayers(2)}
                          >
                            <Text style={[styles.tabText, playerTab === 2 && styles.activeTabText]}>
                             2
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={[styles.tabs, playerTab === 6 && styles.activeTab]}
                            onPress={() => handleSelectPlayers(6)}
                          >
                            <Text style={[styles.tabText, playerTab === 6 && styles.activeTabText]}>
                              6
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={[styles.tabs, playerTab === 9 && styles.activeTab]}
                            onPress={() => handleSelectPlayers(9)}
                          >
                            <Text style={[styles.tabText, playerTab === 9 && styles.activeTabText]}>
                              9
                            </Text>
                          </TouchableOpacity>
                        </View>
                  </View>
                  <View style={{flexDirection:'column',gap:10}}>
                  <Text style={{textAlign:'center'}}>Select Game</Text>
                        <View style={{flexDirection:'row',justifyContent:'center'}}>
                          {/* Tab 1 */}
                          <TouchableOpacity
                            style={[styles.tabs, poolTab === 101 && styles.activeTab]}
                            onPress={() => handleSelectPool(101)}
                          >
                            <Text style={[styles.tabText, poolTab === 101 && styles.activeTabText]}>
                             80
                            </Text>
                          </TouchableOpacity>
                  
                          {/* Tab 2 */}
                          <TouchableOpacity
                            style={[styles.tabs, poolTab === 201 && styles.activeTab]}
                            onPress={() => handleSelectPool(201)}
                          >
                            <Text style={[styles.tabText, poolTab === 201 && styles.activeTabText]}>
                              160
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={[styles.tabs, poolTab === 301 && styles.activeTab]}
                            onPress={() => handleSelectPool(301)}
                          >
                            <Text style={[styles.tabText, poolTab === 301 && styles.activeTabText]}>
                              240
                            </Text>
                          </TouchableOpacity>
                        </View>
                  </View>
                  <View style={{flexDirection:'column',alignItems:'center'}}>
                    <Text style={{textAlign:'center'}}>Select Amount</Text>
      <View style={{ flexDirection: 'row', justifyContent: 'center', padding: 10 }}>
        <View style={{ flexDirection: 'row', width: 'auto', gap: 20 }}>
          <Text>Point value <Text style={{ fontSize: 16, fontWeight: '700' }}>₹ {getCurrentPointValue()}</Text></Text>
          <Text>Entry Fee <Text style={{ fontSize: 16, fontWeight: '700' }}>₹ {getCurrentStepValue()}</Text></Text>
        </View>
      </View>

      {/* Slider */}


      {/* Slider */}
      <View style={{ alignItems: 'center', flexDirection: 'row', justifyContent: 'center',paddingVertical:10 }}>

      <TouchableOpacity onPress={decrementValue} style={{
    flexDirection: 'row',
    gap: 4,
    backgroundColor: '#526E48',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 8,
  }}>
        <Text style={styles.buttonText}><Image style={{height:20,width:20}} source={require('./assets/sub.png')}/></Text>
      </TouchableOpacity>

      {/* Slider */}
      <View style={{width:'70%',flexDirection:'column'}}>

      <Slider
        style={styles.slider}
        minimumValue={0}
        maximumValue={customSteps.length - 1} // 0 to 8 for 9 custom steps
        value={sliderValue}
        onValueChange={handleSliderChange}
        step={1} // Step is 1 to only allow whole numbers (no intermediate values)
        minimumTrackTintColor="#526E48" // Color of the active part of the slider
        maximumTrackTintColor="#D3D3D3"
        thumbTintColor="#526E48" // Color of the inactive part of the slider
      />
      </View>
      

      {/* Increase Button */}
      <TouchableOpacity onPress={incrementValue} style={{
    flexDirection: 'row',
    gap: 4,
    backgroundColor: '#526E48',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 8,
  }}>
        <Text style={styles.buttonText}><Image style={{height:20,width:20}} source={require('./assets/add.png')}/></Text>
      </TouchableOpacity>
    </View>
      
                      </View>
                  <View style={{flexDirection:'row',justifyContent:'center'}} >
                  <TouchableOpacity onPress={createRoom} style={styles.button}><Text style={{color:'#fff'}}>Create Room</Text></TouchableOpacity>
                  </View>
                  </View>
        </View>
    )
}

const styles = StyleSheet.create({
  sidebar: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor:'#fff',
    width: Dimensions.get('window').width * 0.70, // Sidebar takes up 75% of the screen width
    height: '100%',
    marginTop:30, // Dark background for the sidebar
    flexDirection:'row',
    justifyContent: 'flex-end', // Align content from the top
    zIndex: 999, 
  }, 
  slider: {
    width: '80%',
    height: 40,
  },
  markersContainer: {
    position: 'absolute',
    top: -8, // Adjust the position of markers above the slider
    width: '100%',
    height: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  marker: {
    width: 6,
    height: 6,
    backgroundColor: '#526E48', // Color of the marker
    borderRadius: 3,
    position: 'absolute',
    top: 15, // Positioning markers at a reasonable place above the slider
  },
  tabs: {
    paddingVertical:18,
    paddingHorizontal:24,
    borderRadius:8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#fff',

  },
  inputField:{
    width:'50%',
    borderBottomWidth:1,
    borderColor:'#000'
    },
  dimBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Dark overlay with 50% opacity
    zIndex: 998,
  },
  tabContainer: {
    flexDirection: 'row',
    padding: 10,
    width:'100%',
    justifyContent: 'center'
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#526E48', // blue-500
  },
  tab: {
    paddingHorizontal:20,
    paddingVertical:10,
    width:'50%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius:8
  },
  activeTab: {
    backgroundColor: '#526E48',
     // Green for active tab
  },
  tabText: {
    fontWeight: 'bold',
    color: '#000',
    fontSize: 14 // Default text color
  },

  activeTabText: {
    color: '#fff',
    fontWeight: 800 // White text for active tab
  },
  banner: {
    height: 180,
    backgroundColor: '#526E48'
  },
  bottomNavbar: {
    position: 'absolute', 
    bottom: 0,             // Stick to the bottom
    left: 0,     
    right: 0,              // Align to the right
    backgroundColor: '#fff', // Background color for the navbar
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#9D9895',
    paddingHorizontal: 16,
    paddingVertical: 10
  },
  bottomMenu: {
    fontSize: 14,
    fontWeight: 800
  },
  chips: {
    flexDirection: 'column',
    alignItems: 'center',
  },
  show: {
    width: '100%',
    height: 32,
    backgroundColor: '#fff'
  },
  profileImage: {
    width: 48,
    height: 48,
    borderRadius: 24, // rounded-full
  },
  button: {
    flexDirection: 'row',
    gap: 4,
    justifyContent:'center',
    width:120,
    backgroundColor: '#526E48',
    paddingVertical: 12,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff', // blue-500
    fontWeight: 'bold',
  },
});

export default CreatePrivateRoom;
